# group_project
group19 model selection and model diagnostics
